import ProductGrid from "../ProductGrid";

export default function ProductGridExample() {
  return <ProductGrid />;
}
